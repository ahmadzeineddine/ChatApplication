<?php
 
/**
 * File to handle all API requests
 * Accepts GET and POST
 * 
 * Each request will be identified by TAG
 * Response will be JSON data
 
  /**
 * check for POST request 
 */
// include db handler
if (isset($_POST['tag']) && $_POST['tag'] != '') {
    // get tag
    $tag = $_POST['tag'];
	require_once 'include/DB_Functions.php';
	require_once 'include/gcm.php';
	$db = new DB_Functions();
	// response Array
    $response = array("tag" => $tag, "error" => FALSE);
	if($tag == 'get_users'){
		$users = $db->getUsers();
		$gcms = $db->getGCMS();
		if($users != FALSE){
			$response['error'] = FALSE;
			$response['data'] = $users;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, data cannot be retrieved.";
		}
		if($gcms != FALSE){
			$response['error'] = FALSE;
			$response['gcm'] = $gcms;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, gcm data cannot be retrieved.";
		}
	}else if($tag == 'save_reg_id'){
		$imei = $_POST['imei'];
		$reg_id = $_POST['reg_id'];
		$result = $db->storeRegId($imei, $reg_id);
		if($result==FALSE){
			$response['error'] = TRUE;
			$response['error_msg'] = "Error, GCM Token could not be stored";
			return;
		}
		echo $result;
	}else if($tag == 'get_updated_gcms'){
		$timestamp = (int) $_POST['timestamp'];
		$result = $db->getGCMByTimestamp($timestamp);
		if($result!=FALSE){
			$response['error'] = FALSE;
			$response['gcm'] = $result;
		}
	}else if($tag == 'register_user'){
		$uid = $_POST['uid'];
		$jid = $_POST['jid'];
		$name = $_POST['name'];
		date_default_timezone_set('Asia/Beirut');
		$timestamp = time();
		$user = $db->storeUser($uid, $jid, $name, ''.$timestamp);
		if($user){
			$response['error'] = FALSE;
			$response['id'] = $user['id'];
			$response['jid'] = $user['jid'];
			$response['name'] = $user['name'];
		}else{
			$response['error'] = TRUE;
			$response["error_msg"] = "Error, User could not be stored";
		}
	}else if($tag == 'update_user_vcard'){
		$jid = $_POST['jid'];
		date_default_timezone_set('Asia/Beirut');
		$timestamp = time();
		//$timestamp = $_REQUEST['date'];
		$response = $db->updateUserVCardTimestamp($tag, $jid,''.$timestamp);
		if($response != FALSE) {
			echo $response;
			return;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Failure, Error updating vcard.";
		}
	}else if($tag == 'single_user'){
		$gcm = new GCM();
		$pushStatus = "GCM Status Message will appear here";
		$pushMessage = $_POST['message'];
		$to = $_POST['reg_id'];
		$pushMessage = utf8_encode($pushMessage);
		if (isset($pushMessage)) {
			$pushStatus = $gcm->send($to, $pushMessage);
			//file_put_contents("log1.txt", $pushStatus. PHP_EOL, FILE_APPEND);
			$data = json_decode($pushStatus);
			$success = $data->success;
			$results_arr = $data->results;
					
			$pushObj = new StdClass();
			$pushObj->tag = "single_user";
			$pushObj->error = FALSE;
			$pushObj->success = $success;
			$pushObj->message_id = $results_arr[0]->message_id;
			$pushStatus = json_encode($pushObj);
			echo $pushStatus;
		}
	}else{
		$response["error"] = TRUE;
		$response["error_msg"] = "'tag' parameter is not found!";
	}
	echo json_encode($response);
}else{
	$response["error"] = TRUE;
    $response["error_msg"] = "Required parameter 'tag' is missing!";
    echo json_encode($response);
}
?>