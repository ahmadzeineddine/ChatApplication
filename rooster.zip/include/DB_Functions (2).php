<?php
 
class DB_Functions {
 
    private $db;
	private $con;
 
    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->con = $this->db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($reg_id, $username, $imei) {
        $result = mysqli_query($this->con, "INSERT INTO `chatgcm`.`user` (`id`, `reg_id`, `username`, `imei`) VALUES (NULL, '$reg_id', '$username', '$imei')") or die(mysql_error());
        // check for successful store
        if ($result) {
            // get user details 
            $uid = mysqli_insert_id($this->con); // last inserted id
            $result = mysqli_query($this->con, "SELECT * FROM user WHERE id = $uid");
            // return user details
            return mysqli_fetch_array($result, MYSQLI_ASSOC);
        } else {
            return false;
        }
    }
	
	public function getUserRegId($reg_id){
		$result = mysqli_query($this->con, "SELECT * FROM user WHERE reg_id = '$reg_id'") or die(mysql_error());
		$row = $result->fetch_assoc();
        // check for result 
        if($row == null){
			return false;
		}else{
			$no_of_rows = mysqli_num_rows($row);
			if ($no_of_rows > 0) {
				return true;
			} else{
				// user not found
				return false;
			}
		}
	}
	
	public function getUserImei($imei){
		$result = mysqli_query($this->con, "SELECT * FROM user WHERE imei = '$imei'") or die(mysql_error());
		$row = $result->fetch_assoc();
        // check for result 
		if($row == null){
			return false;
		}else{
			$no_of_rows = mysqli_num_rows($result);
			if ($no_of_rows > 0) {
				//file_put_contents("log.txt", $row['id'] . PHP_EOL, FILE_APPEND);
				return $row;
			} else {
				// user not found
				return false;
			}
		}
	}
	
	public function updateUserRegIdAndUsername($row, $username, $reg_id, $imei){
		$result = mysqli_query($this->con, "UPDATE  `chatgcm`.`user` SET `reg_id` =  '$reg_id', `username` = '$username' WHERE  `user`.`imei` = '$imei'") or die(mysql_error());
        // check for successful store
        if ($result) {
			$obj = new stdClass();
			$obj->error = false;
			$obj->error_msg = "No Error";
			$obj->uid = $row['id'];
			$obj->user = new StdClass();
			$obj->user->username = $username;
			$obj->user->reg_id = $reg_id;
			$obj->user->imei = $row['imei'];
            return json_encode($obj);
        } else {
            return false;
        }
	}
	
	public function updateUsername($imei, $username){
		$result = mysqli_query($this->con, "UPDATE  `chatgcm`.`user` SET  `username` =  '$username' WHERE  `user`.`imei` = '$imei'") or die(mysql_error());
        // check for successful store
        if ($result) {
			$obj = new stdClass();
			$obj->error = false;
			$obj->error_msg = "No Error";
			$obj->username = $username;
			$obj->imei = $imei;
            return json_encode($obj);
        } else {
            return false;
        }
	}
	
	public function updateUsernameById($id, $username){
		$result = mysqli_query($this->con, "UPDATE  `chatgcm`.`user` SET  `username` =  '$username' WHERE  `user`.`id` = '$id'") or die(mysql_error());
        // check for successful store
        if ($result) {
			return true;
        } else {
            return false;
        }
	}
	//--------Gets all regIds---------//
	public function getRegId() {
		$sql = "SELECT reg_id FROM user";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		$no_of_rows = mysqli_num_rows($result);
		if($no_of_rows==1){
			$row = $result->fetch_assoc();
			$json = array();
			array_push($json, $row["reg_id"]);
			return $json;
		}
		if($result){
			$json = array();
			while ($row = $result->fetch_assoc()) {
				$json[] = $row["reg_id"];
			}
			return $json;
		}else{
			return false;
		}
    }
	
	public function getAllUsers(){
		$sql = "SELECT * FROM user";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		$no_of_rows = mysqli_num_rows($result);
		if($no_of_rows==1){
			$json = array();
			array_push($json,$result->fetch_assoc());
			return $json;
		}
		if($result){
			$json = array();
			while ($row = $result->fetch_assoc()) {
				$json[] = $row;
			}
			return $json;
		}else{
			return false;
		}
	}
	public function getSmackUsers(){
		$sql = "SELECT * FROM smackxmpp";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		$no_of_rows = mysqli_num_rows($result);
		if($no_of_rows==1){
			$json = array();
			array_push($json,$result->fetch_assoc());
			return $json;
		}
		if($result){
			$json = array();
			while ($row = $result->fetch_assoc()) {
				$json[] = $row;
			}
			return $json;
		}else{
			return false;
		}
	}
	
	public function getSmackUserData($username, $password){
		$result = mysqli_query($this->con, "SELECT * FROM smackxmpp WHERE username = '$username' AND password = '$password'") or die(mysql_error());
		$row = $result->fetch_assoc();
        // check for result 
        $no_of_rows = mysqli_num_rows($result);
        if ($no_of_rows > 0) {
			//file_put_contents("log.txt", $row['name'] . PHP_EOL, FILE_APPEND);
			$name = $row['name'];
			$id = $row['user_id'];
			mysqli_query($this->con, "UPDATE  `chatgcm`.`user` SET  `username` =  '$name' WHERE  `user`.`id` = '$id'") or die(mysql_error());
            return true;
        } else {
            // user not found
            return false;
        }
	}
	
	public function getSmackHostname(){
		$sql = "SELECT * FROM smackhost";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		if($result){
			$json = $result->fetch_assoc();
			return $json;
		}else{
			return false;
		}
	}
	
	public function insertSmackUser($user_id, $name, $username, $password, $blacklist, $blacklisted_me, $connected){
		$result = mysqli_query($this->con, "INSERT INTO `chatgcm`.`smackxmpp` (`id`, `user_id`, `name`, `username`, `password`, `blacklist`, `blacklisted_me`, `connected`) VALUES (NULL, '$user_id', '$name', '$username', '$password', '$blacklist', '$blacklisted_me', '$connected')") or die(mysql_error());
		// check for successful store
		if ($result) {
			// get user details 
			$uid = mysqli_insert_id($this->con); // last inserted id
			$result = mysqli_query($this->con, "SELECT * FROM smackxmpp WHERE id = $uid");
			// return user details
			return mysqli_fetch_array($result, MYSQLI_ASSOC);
		} else {
			return false;
		}
	}
	
	public function updateSmackUserBlacklistByUserId($user_id, $blacklist){
		$result = mysqli_query($this->con, "UPDATE  `chatgcm`.`smackxmpp` SET `blacklist` =  '$blacklist' WHERE  `smackxmpp`.`user_id` = '$user_id'") or die(mysql_error());
        if ($result) {
			return true;
        } else {
            return false;
        }
	}
	
	public function updateSmackUserConnectedByUserId($user_id, $connected){
		$result = mysqli_query($this->con, "UPDATE  `chatgcm`.`smackxmpp` SET `connected` =  '$connected' WHERE  `smackxmpp`.`user_id` = '$user_id'") or die(mysql_error());
        if ($result) {
			return true;
        } else {
            return false;
        }
	}
	
	public function updateSmackUserBlacklistedMeByUserId($user_id, $blacklisted_me){
		$result = mysqli_query($this->con, "UPDATE  `chatgcm`.`smackxmpp` SET `blacklisted_me` =  '$blacklisted_me' WHERE  `smackxmpp`.`user_id` = '$user_id'") or die(mysql_error());
        if ($result) {
			return true;
        } else {
            return false;
        }
	}
	
	public function getSmackUserBlacklistByUserId($user_id){
		$result = mysqli_query($this->con, "SELECT blacklist FROM smackxmpp WHERE user_id = '$user_id'") or die(mysql_error());
		$row = $result->fetch_assoc();
        // check for result 
        $no_of_rows = mysqli_num_rows($result);
        if ($no_of_rows > 0) {
			//file_put_contents("log.txt", $row['name'] . PHP_EOL, FILE_APPEND);
			$blacklist = $row['blacklist'];//$type = 'blacklist';
            return $blacklist;
        } else {
            // user not found
            return false;
        }
	}
	public function getSmackUserBlacklistedMeByUserId($user_id){
		$result = mysqli_query($this->con, "SELECT blacklisted_me FROM smackxmpp WHERE user_id = '$user_id'") or die(mysql_error());
		$row = $result->fetch_assoc();
        // check for result 
        $no_of_rows = mysqli_num_rows($result);
        if ($no_of_rows > 0) {
			//file_put_contents("log.txt", $row['name'] . PHP_EOL, FILE_APPEND);
			$blacklist = $row['blacklisted_me'];
            return $blacklist;
        } else {
            // user not found
            return false;
        }
	}
	
	public function getSmackUserColumnByUserId($user_id, $type){
		$result = mysqli_query($this->con, "SELECT " . $type . " FROM smackxmpp WHERE user_id = '$user_id'") or die(mysql_error());
		$row = $result->fetch_assoc();
        // check for result 
        $no_of_rows = mysqli_num_rows($result);
        if ($no_of_rows > 0) {
			//file_put_contents("log.txt", $row[$type] . PHP_EOL, FILE_APPEND);
			$value = $row[$type];
            return $value;
        } else {
            // user not found
            return false;
        }
	}

 }
 
?>