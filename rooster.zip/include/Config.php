<?php
 
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "mappspec_admin");
define("DB_PASSWORD", "trueLove1234");
define("DB_DATABASE", "roosterdb");
?>