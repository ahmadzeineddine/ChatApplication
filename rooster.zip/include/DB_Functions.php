<?php
 
class DB_Functions {
 
    private $db;
	private $con;
 
    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->con = $this->db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	
	public function getUsers(){
		$sql = "SELECT * FROM user";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		$no_of_rows = mysqli_num_rows($result);
		if($no_of_rows==1){
			$json = array();
			array_push($json,$result->fetch_assoc());
			return $json;
		}
		if($result){
			$json = array();
			date_default_timezone_set('Asia/Beirut');
			while ($row = $result->fetch_assoc()) {
				if($row["vcardtimestamp"]) {
					$timestamp = (int) $row["vcardtimestamp"];
					$vcardDate = date("Y-m-d h:i:s a",$timestamp);
					$row["vcardtimestamp"] = $vcardDate;
				}
				$json[] = $row;
			}
			return $json;
		}else{
			return false;
		}
	}
	
	public function getGCMS(){
		$sql = "SELECT * FROM gcm";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		$no_of_rows = mysqli_num_rows($result);
		if($no_of_rows==1){
			$json = array();
			array_push($json,$result->fetch_assoc());
			return $json;
		}
		if($result){
			$json = array();
			//date_default_timezone_set('Asia/Beirut');
			while ($row = $result->fetch_assoc()) {
				/* if($row["vcardtimestamp"]) {
					$timestamp = (int) $row["vcardtimestamp"];
					$vcardDate = date("Y-m-d h:i:s a",$timestamp);
					$row["vcardtimestamp"] = $vcardDate;
				} */
				$json[] = $row;
			}
			return $json;
		}else{
			return false;
		}
	}
	
	public function storeUser($uid, $jid, $name, $vcardtimestamp) {
        $result = mysqli_query($this->con, "INSERT INTO `roosterdb`.`user` (`id`, `uid`, `jid`, `name`, `vcardtimestamp`) VALUES (NULL, '$uid', '$jid', '$name', '$vcardtimestamp')") or die(mysql_error());
        // check for successful store
        if ($result) {
            // get user details 
            $uid = mysqli_insert_id($this->con); // last inserted id
            $result = mysqli_query($this->con, "SELECT * FROM user WHERE id = $uid");
            // return user details
            return mysqli_fetch_array($result, MYSQLI_ASSOC);
        } else {
            return false;
        }
    }
	
	public function storeRegId($imei, $reg_id){
		$row = $this->getRegId($imei);
		date_default_timezone_set('Asia/Beirut');
		$now = time();
		//$timestamp = date("Y-m-d h:i:s a",$now);
		if($row==false){
			$result = mysqli_query($this->con, "INSERT INTO `roosterdb`.`gcm` (`id`, `imei`, `reg_id`, `timestamp`) VALUES (NULL, '$imei', '$reg_id', $now)") or die(mysql_error());
			// check for successful store
			if ($result) {
				// get user details 
				$id = mysqli_insert_id($this->con); // last inserted id
				// return user details
				$obj = new stdClass();
				$obj->error = false;
				$obj->updated = false;
				$obj->uid = $id;
				$obj->tag = "save_reg_id";
				$obj->imei = $imei;
				$obj->reg_id = $reg_id;
				$obj->timestamp = $now;
				return json_encode($obj);
			} else {
				return false;
			}
		}else{
			$id = $row->id;
			if($reg_id != $row->reg_id){
				//update registration id and timestamp
				$result = mysqli_query($this->con, "UPDATE  `roosterdb`.`gcm` SET `reg_id` =  '$reg_id', `timestamp` = $now WHERE  `gcm`.`id` = '$id'") or die(mysql_error());
				if ($result) {
					$obj = new stdClass();
					$obj->error = false;
					$obj->updated = true;
					$obj->uid = $id;
					$obj->tag = "save_reg_id";
					$obj->imei = $row->imei;
					$obj->reg_id = $row->reg_id;
					$obj->timestamp = $now;
					return json_encode($obj);
				}
			}else{
				$obj = new stdClass();
				$obj->error = false;
				$obj->updated = false;
				$obj->uid = $id;
				$obj->tag = "save_reg_id";
				$obj->imei = $row->imei;
				$obj->reg_id = $row->reg_id;
				$obj->timestamp = $row->timestamp;
				return json_encode($obj);
			}
		}
	}
	
	public function getGCMByTimestamp($timestamp){
		$sql = "SELECT * FROM gcm WHERE timestamp > $timestamp";
		$result = mysqli_query($this->con, $sql) or die(mysqli_error());
		$no_of_rows = mysqli_num_rows($result);
		if($no_of_rows==1){
			$json = array();
			array_push($json,$result->fetch_assoc());
			return $json;
		}
		if($result){
			$json = array();
			while ($row = $result->fetch_assoc()) {
				$json[] = $row;
			}
			return $json;
		}else{
			return false;
		}
	}
	
	public function getRegId($imei){
		$sql = "SELECT * FROM gcm WHERE imei = '$imei'";
		$result = mysqli_query($this->con, $sql) or die(mysql_error());
		if($result){
			//$row = mysqli_fetch_row($result);
			$row = $result->fetch_object();
			return $row;
		}else{
			return false;
		}
	}
	
	public function updateUserVCardTimestamp($tag, $jid, $vcardtimestamp) {
   		$result = mysqli_query($this->con, "UPDATE  `roosterdb`.`user` SET `vcardtimestamp` =  '$vcardtimestamp' WHERE  `user`.`jid` = '$jid'") or die(mysql_error());
		// check for successful store
        if ($result) {
			$obj = new stdClass();
			$obj->error = false;
			$obj->tag = $tag;
			$obj->error_msg = "No Error";
			$obj->user = new StdClass();
			$obj->user->jid = $jid;
			$obj->user->vcardtimestamp = $vcardtimestamp;
			$obj->user->vcardDate = date("Y-m-d h:i:s a",$vcardtimestamp);
            return json_encode($obj);
		}else return false;
    }

 }
 //1493663058
 
?>