<?php
 
/**
 * File to handle all API requests
 * Accepts GET and POST
 * 
 * Each request will be identified by TAG
 * Response will be JSON data
 
  /**
 * check for POST request 
 */
if (isset($_POST['tag']) && $_POST['tag'] != '') {
    // get tag
    $tag = $_POST['tag'];
    // include db handler
    require_once 'include/DB_Functions.php';
    $db = new DB_Functions();
 
    // response Array
    $response = array("tag" => $tag, "error" => FALSE);
	if($tag == 'get_user'){
		$imei = $_POST['imei'];
		$user_imei_exists = $db->getUserImei($imei);
		if(!$user_imei_exists){
			$response["error"] = TRUE;
			$response["error_msg"] = "No user";
		}else{
			$response["error"] = FALSE;
			$response["user_id"] = $user_imei_exists["id"];
			$response["reg_id"] = $user_imei_exists["reg_id"];
			$response["username"] = $user_imei_exists["username"];
			$response["imei"] = $user_imei_exists["imei"];
		}
	}else if($tag == 'register'){
		$reg_id = $_POST['reg_id'];
		$username = $_POST['username'];
		$imei = $_POST['imei'];
		$user_exists = $db->getUserRegId($reg_id);
		
		if(!$user_exists){
			$user_imei_exists = $db->getUserImei($imei);
			if(!$user_imei_exists){
				$user = $db->storeUser($reg_id, $username, $imei);
				if ($user) {
						// user stored successfully
						$response["error"] = FALSE;
						$response["uid"] = $user["id"];
						$response["user"]["reg_id"] = $user["reg_id"];
						$response["user"]["username"] = $user["username"];
						$response["user"]["imei"] = $user["imei"];
				}else {
					// user failed to store
					$response["error"] = TRUE;
					$response["error_msg"] = "Error occured in Registration.";
				}
			}else{
				//Just update the registration id and username
				$update = $db->updateUserRegIdAndUsername($user_imei_exists, $username, $reg_id, $imei);
				if($update != FALSE) {
					echo $update;
					return;
				}else{
					$response["error"] = TRUE;
					$response["error_msg"] = "imei exists, Error updating registration id.";
				}
			}
		}else{
			$response["error"] = TRUE;
			$response['reg_id'] = $reg_id;
			$response["error_msg"] = "Error, user already exists!";
		}
	}else if($tag == 'update_regId'){
		$imei = $_POST['imei'];
		$reg_id = $_POST['reg_id'];
		
		$update = $db->updateUserRegId($imei, $reg_id);
		if($update != FALSE) {
			echo $update;
			return;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error updating registration id.";
		}
	}else if($tag == 'update_username'){
		$imei = $_POST['imei'];
		$username = $_POST['username'];
		
		$update = $db->updateUsername($imei, $username);
		if($update != FALSE) {
			echo $update;
			return;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error updating username.";
		}
	}else if($tag == 'get_all_users'){
		$allUsers = $db->getAllUsers();
		if($allUsers != FALSE){
			$response['error'] = FALSE;
			$response['data'] = $allUsers;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, data cannot be retrieved.";
		}
	}else if($tag == 'get_hostname'){
		$smackhostname = $db->getSmackHostname();
		if($smackhostname != FALSE){
			$response['error'] = FALSE;
			$response['host'] = $smackhostname;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, hostname cannot be retrieved.";
		}
	}else if($tag == 'get_smack_users'){
		$smackUser = $db->getSmackUsers();
		if($smackUser != FALSE){
			$response['error'] = FALSE;
			$response['smack_users'] = $smackUser;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, Smack Users cannot be retrieved.";
		}
	}else if($tag == 'register_smack'){
		$user_id = $_POST['user_id'];
		$name = $_POST['name'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$blacklist = $_POST['blacklist'];
		$blacklisted_me = $_POST['blacklisted_me'];
		$connected = 1;
		//file_put_contents("log.txt", "black list :". $password . PHP_EOL, FILE_APPEND);
		$smackUser = $db->insertSmackUser($user_id, $name, $username, $password, $blacklist, $blacklisted_me, $connected);
		
		if ($smackUser) {
			// user stored successfully
			$response["error"] = FALSE;
			$response["id"] = $smackUser["id"];
			$response["user_id"] = $smackUser["user_id"];
			$response["name"] = $smackUser["name"];
			$response["username"] = $smackUser["username"];
			$response["password"] = $smackUser["password"];
			$response["blacklist"] = $smackUser["blacklist"];
			$response["blacklisted_me"] = $smackUser["blacklisted_me"];
			$response["connected"] = $smackUser["connected"];
			$updated = $db->updateUsernameById($user_id, $name);
			$response['user_updated'] = $updated;
		}else {
			// user failed to store
			$response["error"] = TRUE;
			$response["error_msg"] = "Error occured in Registration.";
		}
		
	}else if($tag == 'login_smack'){
		$name = $_POST['name'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$smackUserOk = $db->getSmackUserData($username, $password);
		if($smackUserOk == TRUE){
			$response['error'] = FALSE;
			$response['authorized'] = TRUE;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, Smack User is not registered.";
		}
	}else if($tag == 'connectivity'){
		$user_id = $_POST['user_id'];
		$connected_str = $_POST['connected'];
		$connected = (int)$connected_str;
		$result = $db->updateSmackUserConnectedByUserId($user_id, $connected);
		if($result==TRUE){
			$response['error'] = FALSE;
			$response['connected'] = $connected;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, Smack User Connectivity couldn't be updated.";
		}
	}else if($tag == 'get_connected'){
		$user_id = $_POST['user_id'];
		//file_put_contents("log.txt", $user_id . PHP_EOL, FILE_APPEND);
		$result = $db->getSmackUserColumnByUserId($user_id, "connected");
		if($result==0 || $result==1){
			$response['error'] = FALSE;
			$response['connected'] = $result;
		}else{
			$response["error"] = TRUE;
			$response["error_msg"] = "Error, Smack User status can't be retrieved.";
		}
	}
	echo json_encode($response);
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter 'tag' is missing!";
    echo json_encode($response);
}
?>