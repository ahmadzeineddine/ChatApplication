-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2017 at 12:20 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `roosterdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `gcm`
--

CREATE TABLE IF NOT EXISTS `gcm` (
  `id` int(14) NOT NULL AUTO_INCREMENT,
  `imei` varchar(18) NOT NULL,
  `reg_id` text NOT NULL,
  `timestamp` int(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `gcm`
--

INSERT INTO `gcm` (`id`, `imei`, `reg_id`, `timestamp`) VALUES
(2, '00000000000001', 'dUrOTe6gloU:APA91bGM5JmfpCJ1AD-ZiWghVIxIDJy2GJ3XlpM3YStYw6y48KYKLApP6IL8xvtTk_PEK5J37UGZUJtLZ7X6wleZ4u4RsbjWBOv0qqT70NSZp48BCgZZOuP-L1VTJchvkJnlT1GZ6tZc', 1494535523),
(3, '0000000000000002', 'ejJMa7mTT6Q:APA91bGNsMuC4Q2PtnSYgOcK3SFxynqPmshuXIj6T8DoiulJnsAWmNFrbGjhBpoOLv-kMs1ATc2iJOCEWwIbcokIhYhNq6EJ_9ihbN3OLjEVyq4fY5u2motrCHeaf4e2x0uzM8ZGfo6P', 1494535697),
(4, '00000000000003', 'cHVE1JQmHTw:APA91bFQCxwCqLKjuDefByixrdo8VPSa7oYwF9bwztlpFaf4GuOQpCcYZCCgvFMKt_mgSQbuMZ3XvK1Gi-wHjz8hAtBa7hUrXeUCJYp6w4FF3pQWCLAlgvh9ajIpGPqZwn9cbM8Wmc9S', 1),
(5, '000000000000000', 'eh6QFP8ksjM:APA91bEcYiZuYrTrrUKtEneOsMVtYddmCd5coXRHw618ChasjFKY2XPppdXesncvZQmH4jbU-fZAnMB_Tl_lm51NUgGEsGJ9y3kEepChdYGZspEERfXNjIyJcRZnRyUxYdssbd-8qbZH', 1495064842);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(14) NOT NULL,
  `jid` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  `vcardtimestamp` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `uid`, `jid`, `name`, `vcardtimestamp`) VALUES
(1, '2', 'finekiss@chatme.im', 'ahmad', '1494424423'),
(4, '3', 'ahmed.zd@chatme.im', 'ahmad zd', '1494195288'),
(7, '4', 'hosein@chatme.im', 'hosein', '1494133450'),
(8, '5', 'lebanexams@chatme.im', 'Adminstrator', '1494133450');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
